<?php 
define('HOST','localhost');   
define('USER','onlinefa_dbcomuser'); 
define('PASS','dbcomuser!@#$'); 
define('DB','onlinefa_dbcom');      
?>
